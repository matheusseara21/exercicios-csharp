using System;
using System.Text.RegularExpressions;

namespace Exercicios {
    public class exer1 {
        public static void Executar() {
            Console.Write("Digite uma senha: ");
            string? entrada = Console.ReadLine();
            if (string.IsNullOrEmpty(entrada)) {
                Console.WriteLine("Entrada inválida.");
                return;
            }
            string senha = entrada;

            bool tamanho = senha.Length >= 8;
            bool maiuscula = Regex.IsMatch(senha, "[A-Z]");
            bool numero = Regex.IsMatch(senha, "[0-9]");
            bool especial = Regex.IsMatch(senha, "[!@#]");

            if (tamanho && maiuscula && numero && especial) {
                Console.WriteLine("Senha forte!");
            } else {
                Console.WriteLine("Senha fraca. Tente novamente.");
            }
        }
    }
}
