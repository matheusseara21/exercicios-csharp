using System;

namespace Exercicios {
    public class exer4 {
        public static void Executar() {
            int opcao;

            do {
                Console.WriteLine("\nMenu de Conversão:");
                Console.WriteLine("1 - Celsius para Fahrenheit");
                Console.WriteLine("2 - Fahrenheit para Celsius");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha uma das opções: ");
                string? entrada = Console.ReadLine();
                if (string.IsNullOrEmpty(entrada)) return;
                opcao = int.Parse(entrada);

                switch (opcao) {
                    case 1:
                        Console.Write("Digite a temperatura em Celsius: ");
                        string? cstr = Console.ReadLine();
                        if (string.IsNullOrEmpty(cstr)) return;
                        double c = double.Parse(cstr);
                        Console.WriteLine($"Fahrenheit: {(c * 9 / 5) + 32}");
                        break;
                    case 2:
                        Console.Write("Digite a temperatura em Fahrenheit: ");
                        string? fstr = Console.ReadLine();
                        if (string.IsNullOrEmpty(fstr)) return;
                        double f = double.Parse(fstr);
                        Console.WriteLine($"Celsius: {(f - 32) * 5 / 9}");
                        break;
                    case 3:
                        Console.WriteLine("Saindo...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }
            } while (opcao != 3);
        }
    }
}
