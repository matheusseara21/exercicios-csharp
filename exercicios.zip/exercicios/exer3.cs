using System;

namespace Exercicios {
    public class exer3 {
        public static void Executar() {
            Console.Write("Informe um número inteiro positivo: ");
            string? entrada = Console.ReadLine();
            if (string.IsNullOrEmpty(entrada)) {
                Console.WriteLine("Entrada inválida.");
                return;
            }
            int numero = int.Parse(entrada);

            if (numero < 0) {
                Console.WriteLine("Número inválido.");
                return;
            }

            int fatorial = 1;
            int i = 1;

            while (i <= numero) {
                fatorial *= i;
                i++;
            }

            Console.WriteLine($"Fatorial de {numero} é {fatorial}");
        }
    }
}
