using System;

namespace Exercicios {
    public class exer2 {
        public static void Executar() {
            Console.Write("Digite um número: ");
            string? entrada = Console.ReadLine();
            if (string.IsNullOrEmpty(entrada)) {
                Console.WriteLine("Entrada inválida.");
                return;
            }
            int numero = int.Parse(entrada);

            for (int i = 1; i <= 10; i++) {
                Console.WriteLine($"{numero} x {i} = {numero * i}");
            }
        }
    }
}
