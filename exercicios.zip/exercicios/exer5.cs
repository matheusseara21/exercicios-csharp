using System;
using System.Linq;

namespace Exercicios {
    public class exer5 {
        public static void Executar() {
            Console.Write("Digite uma palavra ou frase: ");
            string? entrada = Console.ReadLine();
            if (string.IsNullOrEmpty(entrada)) {
                Console.WriteLine("Entrada inválida.");
                return;
            }

            string texto = entrada.ToLower().Replace(" ", "");

            string reverso = new string(texto.Reverse().ToArray());

            if (texto == reverso) {
                Console.WriteLine("É um palíndromo!");
            } else {
                Console.WriteLine("Não é um palíndromo.");
            }
        }
    }
}
