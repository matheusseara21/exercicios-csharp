using System;

class Produto {
    public string Nome { get; set; }
    public double Preco { get; set; }
    public int Quantidade { get; set; }

    public double ValorTotal() {
        return Preco * Quantidade;
    }
}

class Program {
    static void Main() {
        Produto[] produtos = new Produto[3];

        for (int i = 0; i < 3; i++) {
            produtos[i] = new Produto();

            Console.Write($"Nome do produto {i + 1}: ");
            produtos[i].Nome = Console.ReadLine();

            Console.Write("Preço: ");
            produtos[i].Preco = double.Parse(Console.ReadLine());

            Console.Write("Quantidade: ");
            produtos[i].Quantidade = int.Parse(Console.ReadLine());

            Console.WriteLine();
        }

        Console.WriteLine("Produtos cadastrados:");
        foreach (var p in produtos) {
            Console.WriteLine($"{p.Nome} - Total em estoque: R$ {p.ValorTotal():F2}");
        }
    }
}