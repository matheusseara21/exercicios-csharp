using System;

class Program {
    static void Main() {
        Random rand = new Random();
        int numero = rand.Next(1, 101);
        int tentativa, contador = 0;

        Console.WriteLine("Tente adivinhar o número de 1 a 100!");

        do {
            Console.Write("Digite sua tentativa: ");
            tentativa = int.Parse(Console.ReadLine());
            contador++;

            if (tentativa < numero)
                Console.WriteLine("O número é maior.");
            else if (tentativa > numero)
                Console.WriteLine("O número é menor.");
        } while (tentativa != numero);

        Console.WriteLine($"Parabéns! Você acertou em {contador} tentativas.");
    }
}