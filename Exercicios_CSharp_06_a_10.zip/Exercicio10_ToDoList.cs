using System;
using System.Collections.Generic;

class Program {
    static void Main() {
        List<string> tarefas = new List<string>();
        List<bool> concluidas = new List<bool>();
        string entrada;

        do {
            Console.Write("Digite uma tarefa (ou 'sair' para encerrar): ");
            entrada = Console.ReadLine();

            if (entrada.ToLower() != "sair") {
                tarefas.Add(entrada);
                concluidas.Add(false);
            }
        } while (entrada.ToLower() != "sair");

        for (int i = 0; i < tarefas.Count; i++) {
            Console.Write($"Tarefa {i + 1}: {tarefas[i]} - Concluída? (s/n): ");
            string resposta = Console.ReadLine();
            if (resposta.ToLower() == "s") {
                concluidas[i] = true;
            }
        }

        Console.WriteLine("\nTarefas:");
        for (int i = 0; i < tarefas.Count; i++) {
            string status = concluidas[i] ? "✔️ Concluída" : "❌ Pendente";
            Console.WriteLine($"{i + 1}. {tarefas[i]} - {status}");
        }
    }
}